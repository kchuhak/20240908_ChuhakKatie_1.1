public class Main {
    public static void main(String[] args) {
        // displays the following messages
        System.out.println("Welcome to Java");
        System.out.println("Welcome to Computer Science");
        System.out.println("Programming is fun");
    }
}